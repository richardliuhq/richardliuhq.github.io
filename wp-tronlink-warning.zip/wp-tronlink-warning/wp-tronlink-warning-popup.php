<?php
/**
 * @package Tronlink warning popup if Tronlink is not ready yet
 * @version 0.2
 */
/*
Plugin Name: Tronlink warning popup
Plugin URI: https://github.com/SmashTraders/SmashTraders
Description: If Tronlink is ready yet, this trigger the popup window
Author: Richard L
Version: 0.2
Author URI: https://github.com/SmashTraders/SmashTraders
*/
	if ( !is_admin() ){
		/* Call the Tronlink checking script after the page loading */
		add_action('wp_loaded', 'tronlink_checking');

		function tronlink_checking() {
			tronlink_checking_page();
		}
	}
?>

<?php
function tronlink_checking_page() {
	wp_register_style('warningdialogstylesheet', '/wp-content/plugins/wp-tronlink-warning/dialog.css');
	wp_enqueue_style('warningdialogstylesheet');

	wp_register_style('bootstrapsheet', '/wp-content/plugins/wp-tronlink-warning/bootstrap.min.css');
	wp_enqueue_style('bootstrapsheet');

	wp_register_script('tronweb_script','/wp-content/plugins/wp-tronlink-warning/TronWeb.js');
    wp_enqueue_script('tronweb_script');

	wp_register_script('Tronlink_script','/wp-content/plugins/wp-tronlink-warning/TronLinkChecking.js');
    wp_enqueue_script('Tronlink_script');

?>
            <div class="container">
				<div id="myModal" class="modal">
					  <!-- Modal content -->
					<div class="modal-content">
						<div class="modal-header">
							 <span class="close">×</span>
							<h2>Please log in TRON Chrome Wallet.</h2>
						</div>
						<div class="modal-body">

							If you have not downloaded the wallet, please download the Chrome extensions:
							<a href="https://chrome.google.com/webstore/detail/tronlink/ibnejdfjmmkpcnlpebklmnkoeoihofec" target="view_window">TronLink</a><br>

							Please switch wallet to mainnet node, don't use testnet node

							After logging in to the wallet or switching accounts, please refresh the page before starting the Tournament.

						</div>
					</div>
				</div>
			</div>

<?php
}
?>